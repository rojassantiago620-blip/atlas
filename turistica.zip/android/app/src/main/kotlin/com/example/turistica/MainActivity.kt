package com.example.turistica

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
