import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:geolocator/geolocator.dart';

void main() {
  runApp(const AtlasApp());
}

// ---------------------------------------------------------------------------
// MODELO
// ---------------------------------------------------------------------------
class Site {
  final String name;
  final String city;
  final String country;
  final String code;
  final double lat;
  final double lng;
  final String desc;
  final String look;
  final String food;
  final String wiki;

  const Site({
    required this.name,
    required this.city,
    required this.country,
    required this.code,
    required this.lat,
    required this.lng,
    required this.desc,
    required this.look,
    required this.food,
    required this.wiki,
  });
}

// ---------------------------------------------------------------------------
// DATOS: 64 SITIOS TURÍSTICOS DEL MUNDO
// ---------------------------------------------------------------------------
const List<Site> sites = [
  Site(
      name: 'Torre Eiffel',
      city: 'París',
      country: 'Francia',
      code: 'FR',
      lat: 48.8584,
      lng: 2.2945,
      wiki: 'Eiffel_Tower',
      desc:
          'Torre de hierro de 330 m construida en 1889 por Gustave Eiffel, símbolo de París.',
      look:
          'Estructura calada que cambia de color al anochecer; se sube en ascensor hasta el tercer piso.',
      food: 'Croissant y café en una terraza cerca del Campo de Marte.'),
  Site(
      name: 'Coliseo',
      city: 'Roma',
      country: 'Italia',
      code: 'IT',
      lat: 41.8902,
      lng: 12.4922,
      wiki: 'Colosseum',
      desc:
          'Anfiteatro romano del año 80 d.C., el más grande construido por el Imperio Romano.',
      look:
          'Piedra desgastada por dos mil años y arcos repetidos en cuatro niveles.',
      food: 'Cacio e pepe en una trattoria del barrio de Monti.'),
  Site(
      name: 'Sagrada Familia',
      city: 'Barcelona',
      country: 'España',
      code: 'ES',
      lat: 41.4036,
      lng: 2.1744,
      wiki: 'Sagrada_Família',
      desc: 'Basílica de Gaudí en construcción desde 1882, aún sin terminar.',
      look:
          'Torres que parecen árboles de piedra y vitrales que tiñen el interior de colores.',
      food: 'Pan con tomate y jamón ibérico en el Eixample.'),
  Site(
      name: 'Big Ben',
      city: 'Londres',
      country: 'Reino Unido',
      code: 'GB',
      lat: 51.5007,
      lng: -0.1246,
      wiki: 'Big_Ben',
      desc: 'Torre del reloj del Parlamento británico, terminada en 1859.',
      look:
          'Aguja neogótica junto al Támesis, con campanadas que se escuchan por todo Westminster.',
      food: 'Fish and chips recién hechos junto al río.'),
  Site(
      name: 'Torre de Pisa',
      city: 'Pisa',
      country: 'Italia',
      code: 'IT',
      lat: 43.7230,
      lng: 10.3966,
      wiki: 'Leaning_Tower_of_Pisa',
      desc:
          'Campanario del siglo XII, inclinado por un terreno inestable desde su construcción.',
      look:
          'Mármol blanco y una inclinación de casi 4 grados que sorprende al verla de cerca.',
      food: 'Pappardelle al cinghiale y pecorino toscano.'),
  Site(
      name: 'Acrópolis',
      city: 'Atenas',
      country: 'Grecia',
      code: 'GR',
      lat: 37.9715,
      lng: 23.7267,
      wiki: 'Acropolis_of_Athens',
      desc:
          'Conjunto de templos clásicos sobre una colina de Atenas, con el Partenón como centro.',
      look:
          'Columnas de mármol dorado por el sol, con toda la ciudad extendida abajo.',
      food: 'Souvlaki y tzatziki en una taberna de Plaka.'),
  Site(
      name: 'Museo del Louvre',
      city: 'París',
      country: 'Francia',
      code: 'FR',
      lat: 48.8606,
      lng: 2.3376,
      wiki: 'Louvre',
      desc:
          'El museo más visitado del mundo, antiguo palacio real desde el siglo XII.',
      look:
          'Salas interminables bajo la pirámide de vidrio, con la Mona Lisa como parada obligada.',
      food: 'Macarons y café con leche cerca del Palais Royal.'),
  Site(
      name: 'Puente de Carlos',
      city: 'Praga',
      country: 'Chequia',
      code: 'CZ',
      lat: 50.0865,
      lng: 14.4114,
      wiki: 'Charles_Bridge',
      desc:
          'Puente gótico del siglo XIV sobre el río Moldava, flanqueado por 30 estatuas.',
      look:
          'Piedra oscura, músicos callejeros y vista directa al Castillo de Praga.',
      food: 'Trdelník caliente comprado en algún puesto del puente.'),
  Site(
      name: 'Alhambra',
      city: 'Granada',
      country: 'España',
      code: 'ES',
      lat: 37.1760,
      lng: -3.5881,
      wiki: 'Alhambra',
      desc:
          'Fortaleza y palacio nazarí del siglo XIII, ejemplo máximo del arte islámico en España.',
      look:
          'Patios con estanques, yeserías talladas al detalle y jardines del Generalife.',
      food: 'Tapas y vino dulce en el barrio del Albaicín.'),
  Site(
      name: 'Duomo de Milán',
      city: 'Milán',
      country: 'Italia',
      code: 'IT',
      lat: 45.4642,
      lng: 9.1900,
      wiki: 'Milan_Cathedral',
      desc:
          'Catedral gótica con más de 3.400 estatuas, construida a lo largo de casi seis siglos.',
      look:
          'Agujas de mármol blanco que se recorren por la azotea con vista a los Alpes.',
      food: 'Risotto alla milanese en una trattoria cercana.'),
  Site(
      name: 'Neuschwanstein',
      city: 'Baviera',
      country: 'Alemania',
      code: 'DE',
      lat: 47.5576,
      lng: 10.7498,
      wiki: 'Neuschwanstein_Castle',
      desc:
          'Castillo romántico del siglo XIX mandado construir por el rey Luis II de Baviera.',
      look:
          'Torres blancas sobre un bosque alpino, inspiración del castillo de Disney.',
      food: 'Salchichas bávaras y un pretzel recién horneado.'),
  Site(
      name: 'Plaza Roja',
      city: 'Moscú',
      country: 'Rusia',
      code: 'RU',
      lat: 55.7539,
      lng: 37.6208,
      wiki: 'Red_Square',
      desc:
          'Plaza central de Moscú desde el siglo XV, junto al Kremlin y la Catedral de San Basilio.',
      look:
          'Adoquines rojos, cúpulas de colores en forma de bulbo y los muros del Kremlin al fondo.',
      food: 'Borsch y pelmeni en un restaurante cercano.'),
  Site(
      name: 'Stonehenge',
      city: 'Wiltshire',
      country: 'Reino Unido',
      code: 'GB',
      lat: 51.1789,
      lng: -1.8262,
      wiki: 'Stonehenge',
      desc:
          'Círculo de piedras prehistórico de hace más de 4.000 años, de propósito aún debatido.',
      look:
          'Bloques de piedra de varias toneladas alineados con el sol en los solsticios.',
      food: 'Té y scones en algún salón de té cercano.'),
  Site(
      name: 'Canales de Ámsterdam',
      city: 'Ámsterdam',
      country: 'Países Bajos',
      code: 'NL',
      lat: 52.3676,
      lng: 4.9041,
      wiki: 'Canals_of_Amsterdam',
      desc:
          'Red de canales del siglo XVII declarada Patrimonio de la Humanidad.',
      look:
          'Casas estrechas junto al agua, bicicletas por todas partes y puentes iluminados de noche.',
      food: 'Arenque crudo y un stroopwafel recién hecho.'),
  Site(
      name: 'Taj Mahal',
      city: 'Agra',
      country: 'India',
      code: 'IN',
      lat: 27.1751,
      lng: 78.0421,
      wiki: 'Taj_Mahal',
      desc:
          'Mausoleo de mármol blanco del siglo XVII, construido por amor por el emperador Shah Jahan.',
      look:
          'Simetría perfecta reflejada en un estanque, con incrustaciones de piedras semipreciosas.',
      food: 'Petha, dulce de calabaza, especialidad de Agra.'),
  Site(
      name: 'Gran Muralla China',
      city: 'Badaling',
      country: 'China',
      code: 'CN',
      lat: 40.4319,
      lng: 116.5704,
      wiki: 'Great_Wall_of_China',
      desc:
          'Más de 21.000 km de murallas construidas por varias dinastías para proteger el norte de China.',
      look:
          'Escalones empinados sobre crestas de montaña y torres de vigilancia cada pocos cientos de metros.',
      food: 'Pato laqueado en los pueblos al pie de la muralla.'),
  Site(
      name: 'Angkor Wat',
      city: 'Siem Reap',
      country: 'Camboya',
      code: 'KH',
      lat: 13.4125,
      lng: 103.8670,
      wiki: 'Angkor_Wat',
      desc:
          'El templo religioso más grande del mundo, construido en el siglo XII por el imperio jemer.',
      look:
          'Torres en forma de flor de loto reflejadas en fosos, mejor al amanecer.',
      food: 'Amok, curry de pescado envuelto en hoja de plátano.'),
  Site(
      name: 'Monte Fuji',
      city: 'Honshu',
      country: 'Japón',
      code: 'JP',
      lat: 35.3606,
      lng: 138.7274,
      wiki: 'Mount_Fuji',
      desc: 'El volcán más alto de Japón, símbolo del país desde hace siglos.',
      look:
          'Cono nevado casi perfecto, visible desde Tokio en los días despejados.',
      food: 'Fideos soba fríos en un pueblo al pie de la montaña.'),
  Site(
      name: 'Petra',
      city: 'Wadi Musa',
      country: 'Jordania',
      code: 'JO',
      lat: 30.3285,
      lng: 35.4444,
      wiki: 'Petra',
      desc: 'Ciudad nabatea tallada en roca rosada hace más de 2.000 años.',
      look:
          'Un cañón estrecho que se abre de golpe frente al Tesoro, fachada de 40 m en piedra.',
      food: 'Mansaf, cordero en yogur fermentado, plato nacional jordano.'),
  Site(
      name: 'Pabellón Dorado',
      city: 'Kioto',
      country: 'Japón',
      code: 'JP',
      lat: 35.0394,
      lng: 135.7292,
      wiki: 'Kinkaku-ji',
      desc:
          'Templo zen cubierto en pan de oro, reconstruido en 1955 tras un incendio.',
      look:
          'Reflejo dorado sobre un estanque tranquilo, rodeado de jardines cuidados al detalle.',
      food: 'Té matcha y dulces yatsuhashi en Kioto.'),
  Site(
      name: 'Burj Khalifa',
      city: 'Dubái',
      country: 'Emiratos Árabes Unidos',
      code: 'AE',
      lat: 25.1972,
      lng: 55.2744,
      wiki: 'Burj_Khalifa',
      desc:
          'El edificio más alto del mundo, con 828 metros, inaugurado en 2010.',
      look:
          'Aguja de vidrio y acero que domina el horizonte de Dubái, con mirador en el piso 148.',
      food: 'Shawarma y hummus en algún restaurante del centro.'),
  Site(
      name: 'Ciudad Prohibida',
      city: 'Pekín',
      country: 'China',
      code: 'CN',
      lat: 39.9163,
      lng: 116.3972,
      wiki: 'Forbidden_City',
      desc:
          'Palacio imperial chino habitado por emperadores durante casi 500 años.',
      look:
          'Casi mil edificios de techos dorados y patios inmensos en el centro de Pekín.',
      food: 'Pato pekinés, el plato insignia de la ciudad.'),
  Site(
      name: 'Borobudur',
      city: 'Java',
      country: 'Indonesia',
      code: 'ID',
      lat: -7.6079,
      lng: 110.2038,
      wiki: 'Borobudur',
      desc:
          'El templo budista más grande del mundo, construido en el siglo IX en Java.',
      look:
          'Nueve plataformas escalonadas con más de 500 budas de piedra, espectacular al amanecer.',
      food: 'Gudeg, guiso dulce de yaca, típico de la zona.'),
  Site(
      name: 'Bahía de Ha Long',
      city: 'Quang Ninh',
      country: 'Vietnam',
      code: 'VN',
      lat: 20.9101,
      lng: 107.1839,
      wiki: 'Ha_Long_Bay',
      desc:
          'Bahía con miles de islotes de piedra caliza cubiertos de vegetación.',
      look:
          'Aguas verde esmeralda entre formaciones rocosas, se recorre en barco tradicional.',
      food: 'Pescado y marisco fresco preparado directamente en los barcos.'),
  Site(
      name: 'Registán',
      city: 'Samarcanda',
      country: 'Uzbekistán',
      code: 'UZ',
      lat: 39.6542,
      lng: 66.9597,
      wiki: 'Registan',
      desc:
          'Plaza central de Samarcanda rodeada de tres madrasas del siglo XV y XVII.',
      look:
          'Fachadas cubiertas de mosaicos azules y turquesa, punto clave de la Ruta de la Seda.',
      food: 'Plov, arroz con cordero y zanahoria, plato nacional uzbeko.'),
  Site(
      name: 'Wat Arun',
      city: 'Bangkok',
      country: 'Tailandia',
      code: 'TH',
      lat: 13.7437,
      lng: 100.4888,
      wiki: 'Wat_Arun',
      desc:
          'Templo budista a orillas del río Chao Phraya, conocido como el Templo del Amanecer.',
      look:
          'Torre central cubierta de porcelana y conchas que brillan con la primera luz del día.',
      food: 'Pad thai callejero cerca del río.'),
  Site(
      name: 'Palacio de Potala',
      city: 'Lhasa',
      country: 'China (Tíbet)',
      code: 'CN',
      lat: 29.6558,
      lng: 91.1177,
      wiki: 'Potala_Palace',
      desc:
          'Antigua residencia del Dalái Lama, a más de 3.700 metros de altura.',
      look:
          'Muros rojos y blancos que trepan la montaña, con más de mil habitaciones.',
      food:
          'Momos tibetanos, empanadillas al vapor rellenas de carne o verdura.'),
  Site(
      name: 'Torre de Tokio',
      city: 'Tokio',
      country: 'Japón',
      code: 'JP',
      lat: 35.6586,
      lng: 139.7454,
      wiki: 'Tokyo_Tower',
      desc:
          'Torre de comunicaciones de 333 metros inspirada en la Torre Eiffel, inaugurada en 1958.',
      look:
          'Estructura roja y blanca que se ilumina de noche sobre el skyline de Tokio.',
      food: 'Ramen en algún local pequeño cerca de la torre.'),
  Site(
      name: 'Pirámides de Guiza',
      city: 'El Cairo',
      country: 'Egipto',
      code: 'EG',
      lat: 29.9792,
      lng: 31.1342,
      wiki: 'Great_Pyramid_of_Giza',
      desc:
          'Las últimas de las siete maravillas del mundo antiguo, con más de 4.500 años.',
      look:
          'Tres pirámides y la Esfinge sobre el borde del desierto, con El Cairo detrás.',
      food: 'Koshari: arroz, lentejas y pasta con salsa de tomate picante.'),
  Site(
      name: 'Cataratas Victoria',
      city: 'Livingstone',
      country: 'Zambia / Zimbabue',
      code: 'ZW',
      lat: -17.9243,
      lng: 25.8572,
      wiki: 'Victoria_Falls',
      desc:
          'Una de las cataratas más grandes del mundo, en la frontera de Zambia y Zimbabue.',
      look:
          'Cortina de agua de 1.700 metros de ancho, con neblina visible a kilómetros.',
      food: 'Nshima, puré de maíz, con pescado del río Zambeze.'),
  Site(
      name: 'Kilimanjaro',
      city: 'Moshi',
      country: 'Tanzania',
      code: 'TZ',
      lat: -3.0674,
      lng: 37.3556,
      wiki: 'Mount_Kilimanjaro',
      desc: 'La montaña más alta de África, con 5.895 metros y cumbre nevada.',
      look: 'Cambia de sabana a glaciar en un solo ascenso de varios días.',
      food: 'Ugali con guiso de carne en los pueblos al pie de la montaña.'),
  Site(
      name: 'Medina de Marrakech',
      city: 'Marrakech',
      country: 'Marruecos',
      code: 'MA',
      lat: 31.6295,
      lng: -7.9811,
      wiki: 'Medina_of_Marrakesh',
      desc: 'Centro histórico amurallado con más de mil años de antigüedad.',
      look:
          'Callejones estrechos, zocos llenos de color y la plaza Jemaa el-Fna al atardecer.',
      food: 'Tajín de cordero con ciruelas pasas y almendras.'),
  Site(
      name: 'Abu Simbel',
      city: 'Asuán',
      country: 'Egipto',
      code: 'EG',
      lat: 22.3372,
      lng: 31.6258,
      wiki: 'Abu_Simbel_temples',
      desc:
          'Dos templos tallados en roca por Ramsés II hace más de 3.200 años.',
      look:
          'Cuatro estatuas colosales del faraón custodiando la entrada junto al lago Nasser.',
      food: 'Ful medames, guiso de habas, común en todo Egipto.'),
  Site(
      name: 'Zanzíbar',
      city: 'Stone Town',
      country: 'Tanzania',
      code: 'TZ',
      lat: -6.1659,
      lng: 39.2026,
      wiki: 'Zanzibar',
      desc:
          'Isla del océano Índico con una historia de comercio de especias de siglos.',
      look:
          'Playas de arena blanca y Stone Town, un laberinto de calles con puertas talladas.',
      food: 'Pilau de especias y pescado a la parrilla frente al mar.'),
  Site(
      name: 'Cráter del Ngorongoro',
      city: 'Arusha',
      country: 'Tanzania',
      code: 'TZ',
      lat: -3.2000,
      lng: 35.5000,
      wiki: 'Ngorongoro_Crater',
      desc:
          'Caldera volcánica de 20 km de diámetro, hogar de miles de animales.',
      look:
          'Un valle cerrado donde leones, elefantes y flamencos conviven casi sin salir de allí.',
      food: 'Nyama choma, carne asada, típica de Tanzania.'),
  Site(
      name: 'Isla Robben',
      city: 'Ciudad del Cabo',
      country: 'Sudáfrica',
      code: 'ZA',
      lat: -33.8067,
      lng: 18.3667,
      wiki: 'Robben_Island',
      desc:
          'Isla frente a Ciudad del Cabo donde Nelson Mandela estuvo preso 18 años.',
      look:
          'Antigua prisión convertida en museo, con recorridos guiados por exreclusos.',
      food: 'Bobotie, guiso de carne al horno con curry, plato sudafricano.'),
  Site(
      name: 'Estatua de la Libertad',
      city: 'Nueva York',
      country: 'Estados Unidos',
      code: 'US',
      lat: 40.6892,
      lng: -74.0445,
      wiki: 'Statue_of_Liberty',
      desc:
          'Regalo de Francia a Estados Unidos en 1886, símbolo de la llegada de inmigrantes.',
      look:
          '93 metros de cobre verdoso sobre una isla propia en la bahía de Nueva York.',
      food: 'Un bagel con queso crema o un hot dog de carrito.'),
  Site(
      name: 'Gran Cañón',
      city: 'Arizona',
      country: 'Estados Unidos',
      code: 'US',
      lat: 36.1069,
      lng: -112.1129,
      wiki: 'Grand_Canyon',
      desc: 'Cañón tallado por el río Colorado a lo largo de millones de años.',
      look:
          'Capas de roca de colores que se pierden en un abismo de más de 1.800 metros.',
      food: 'Chili con carne en algún restaurante del borde sur.'),
  Site(
      name: 'Chichén Itzá',
      city: 'Yucatán',
      country: 'México',
      code: 'MX',
      lat: 20.6843,
      lng: -88.5678,
      wiki: 'Chichen_Itza',
      desc:
          'Ciudad maya cuya pirámide principal, El Castillo, funcionaba como calendario astronómico.',
      look: 'Templos de piedra caliza en medio de la selva de Yucatán.',
      food: 'Cochinita pibil, cerdo horneado envuelto en hoja de plátano.'),
  Site(
      name: 'Cataratas del Niágara',
      city: 'Ontario',
      country: 'Canadá / Estados Unidos',
      code: 'CA',
      lat: 43.0962,
      lng: -79.0377,
      wiki: 'Niagara_Falls',
      desc:
          'Tres cataratas en la frontera de Canadá y Estados Unidos, entre las más caudalosas del mundo.',
      look:
          'Cortina de agua constante con arcoíris casi permanente en días soleados.',
      food: 'Poutine, papas con queso y salsa, del lado canadiense.'),
  Site(
      name: 'Golden Gate',
      city: 'San Francisco',
      country: 'Estados Unidos',
      code: 'US',
      lat: 37.8199,
      lng: -122.4783,
      wiki: 'Golden_Gate_Bridge',
      desc:
          'Puente colgante de 1937 que cruza la entrada a la bahía de San Francisco.',
      look:
          'Torres de acero color naranja internacional, casi siempre envueltas en niebla.',
      food: 'Clam chowder servido en un pan tipo sourdough.'),
  Site(
      name: 'Teotihuacán',
      city: 'Estado de México',
      country: 'México',
      code: 'MX',
      lat: 19.6925,
      lng: -98.8438,
      wiki: 'Teotihuacan',
      desc:
          'Antigua ciudad prehispánica con dos de las pirámides más grandes de América.',
      look:
          'La Pirámide del Sol y la de la Luna alineadas sobre la Calzada de los Muertos.',
      food: 'Tacos al pastor en los puestos cercanos a la zona.'),
  Site(
      name: 'Times Square',
      city: 'Nueva York',
      country: 'Estados Unidos',
      code: 'US',
      lat: 40.7580,
      lng: -73.9855,
      wiki: 'Times_Square',
      desc:
          'Cruce de avenidas en Manhattan, centro teatral y comercial de Nueva York.',
      look:
          'Pantallas gigantes encendidas día y noche y multitudes constantes.',
      food: 'Pizza por porción, clásica de Nueva York.'),
  Site(
      name: 'CN Tower',
      city: 'Toronto',
      country: 'Canadá',
      code: 'CA',
      lat: 43.6426,
      lng: -79.3871,
      wiki: 'CN_Tower',
      desc:
          'Torre de comunicaciones de 553 metros, una de las más altas de América.',
      look:
          'Mirador con piso de vidrio para ver la ciudad directamente bajo los pies.',
      food: 'Poutine y un café en algún local del centro de Toronto.'),
  Site(
      name: 'Ciudad Amurallada',
      city: 'Cartagena',
      country: 'Colombia',
      code: 'CO',
      lat: 10.4236,
      lng: -75.5517,
      wiki: 'Walled_City_of_Cartagena',
      desc:
          'Centro histórico colonial del siglo XVI, Patrimonio de la Humanidad.',
      look:
          'Calles empedradas, balcones con buganvillas y fuertes de piedra frente al mar.',
      food: 'Arepa de huevo y pescado frito frente a la bahía.'),
  Site(
      name: 'Tikal',
      city: 'Petén',
      country: 'Guatemala',
      code: 'GT',
      lat: 17.2220,
      lng: -89.6237,
      wiki: 'Tikal',
      desc:
          'Antigua ciudad maya con templos que sobresalen por encima de la selva del Petén.',
      look:
          'Pirámides de piedra rodeadas de jungla espesa, con monos aulladores de fondo.',
      food: 'Tamales envueltos en hoja de plátano, típicos de Guatemala.'),
  Site(
      name: 'Arrecife de Belice',
      city: 'Belice',
      country: 'Belice',
      code: 'BZ',
      lat: 17.3000,
      lng: -87.7000,
      wiki: 'Belize_Barrier_Reef',
      desc:
          'El segundo arrecife de coral más grande del mundo, Patrimonio de la Humanidad.',
      look:
          'Aguas turquesas transparentes con el Gran Agujero Azul visible desde el aire.',
      food:
          'Pescado a la parrilla con arroz y frijoles, plato tradicional beliceño.'),
  Site(
      name: 'La Habana Vieja',
      city: 'La Habana',
      country: 'Cuba',
      code: 'CU',
      lat: 23.1367,
      lng: -82.3589,
      wiki: 'Old_Havana',
      desc:
          'Centro histórico colonial cubano, Patrimonio de la Humanidad desde 1982.',
      look:
          'Fachadas coloridas, autos clásicos de los años 50 y plazas coloniales bien conservadas.',
      food: 'Ropa vieja y un mojito en algún bar del centro.'),
  Site(
      name: 'Machu Picchu',
      city: 'Cusco',
      country: 'Perú',
      code: 'PE',
      lat: -13.1631,
      lng: -72.5450,
      wiki: 'Machu_Picchu',
      desc:
          'Ciudadela inca del siglo XV escondida entre montañas a 2.430 metros de altura.',
      look:
          'Terrazas de piedra que trepan la ladera, niebla andina y llamas pastando entre los muros.',
      food: 'Papa a la huancaína y quinoa de los valles cercanos.'),
  Site(
      name: 'Cristo Redentor',
      city: 'Río de Janeiro',
      country: 'Brasil',
      code: 'BR',
      lat: -22.9519,
      lng: -43.2105,
      wiki: 'Christ_the_Redeemer_(statue)',
      desc: 'Estatua de 38 metros en el cerro Corcovado, inaugurada en 1931.',
      look:
          'Brazos abiertos sobre toda la bahía de Guanabara, con Río extendido abajo.',
      food: 'Feijoada y una caipirinha cerca de Copacabana.'),
  Site(
      name: 'Cataratas de Iguazú',
      city: 'Misiones',
      country: 'Argentina / Brasil',
      code: 'AR',
      lat: -25.6953,
      lng: -54.4367,
      wiki: 'Iguazu_Falls',
      desc:
          'Sistema de 275 saltos de agua en la frontera de Argentina y Brasil.',
      look:
          'Selva húmeda, la Garganta del Diablo y una neblina que se ve desde lejos.',
      food: 'Asado argentino con chimichurri.'),
  Site(
      name: 'Salar de Uyuni',
      city: 'Potosí',
      country: 'Bolivia',
      code: 'BO',
      lat: -20.1338,
      lng: -67.4891,
      wiki: 'Salar_de_Uyuni',
      desc:
          'El desierto de sal más grande del mundo, a 3.656 metros de altura.',
      look:
          'Una superficie blanca que se convierte en espejo perfecto tras la lluvia.',
      food: 'Salteñas, empanadas horneadas rellenas de carne y papa.'),
  Site(
      name: 'Monserrate',
      city: 'Bogotá',
      country: 'Colombia',
      code: 'CO',
      lat: 4.6058,
      lng: -74.0567,
      wiki: 'Monserrate',
      desc:
          'Cerro tutelar de Bogotá a 3.152 metros, con un santuario en la cima.',
      look:
          'Vistas de toda la sabana bogotana, funicular y teleférico para subir.',
      food: 'Ajiaco santafereño y obleas con arequipe.'),
  Site(
      name: 'Glaciar Perito Moreno',
      city: 'El Calafate',
      country: 'Argentina',
      code: 'AR',
      lat: -50.4967,
      lng: -73.1378,
      wiki: 'Perito_Moreno_Glacier',
      desc:
          'Uno de los pocos glaciares del mundo que sigue avanzando en lugar de retroceder.',
      look:
          'Paredes de hielo azul de 60 metros que se desprenden en el lago con estruendo.',
      food: 'Cordero patagónico asado al palo.'),
  Site(
      name: 'Isla de Pascua',
      city: 'Rapa Nui',
      country: 'Chile',
      code: 'CL',
      lat: -27.1127,
      lng: -109.3497,
      wiki: 'Easter_Island',
      desc:
          'Isla remota del Pacífico famosa por sus estatuas monumentales, los moáis.',
      look:
          'Cientos de figuras de piedra frente al mar, talladas hace siglos por el pueblo rapa nui.',
      food: 'Ceviche de atún con camote.'),
  Site(
      name: 'Caño Cristales',
      city: 'La Macarena',
      country: 'Colombia',
      code: 'CO',
      lat: 2.2167,
      lng: -73.7833,
      wiki: 'Caño_Cristales',
      desc:
          "Río colombiano conocido como 'el río de los cinco colores' por una planta acuática única.",
      look:
          'Aguas transparentes con manchas rojas, verdes y amarillas entre junio y noviembre.',
      food: 'Pescado del río acompañado de plátano, típico de La Macarena.'),
  Site(
      name: 'Ciudad Perdida',
      city: 'Sierra Nevada de Santa Marta',
      country: 'Colombia',
      code: 'CO',
      lat: 11.0389,
      lng: -73.9239,
      wiki: 'Ciudad_Perdida',
      desc:
          'Asentamiento indígena tayrona anterior a Machu Picchu, en la Sierra Nevada de Santa Marta.',
      look:
          'Terrazas de piedra cubiertas de selva, a las que solo se llega tras varios días de caminata.',
      food: 'Pescado frito y frutas tropicales en los pueblos cercanos.'),
  Site(
      name: 'Torres del Paine',
      city: 'Patagonia',
      country: 'Chile',
      code: 'CL',
      lat: -50.9423,
      lng: -73.4068,
      wiki: 'Torres_del_Paine_National_Park',
      desc:
          'Parque nacional patagónico con tres macizos de granito que dan nombre al lugar.',
      look:
          'Torres de roca gris sobre lagos turquesa y glaciares, típico de la Patagonia chilena.',
      food: 'Cordero magallánico asado a la estaca.'),
  Site(
      name: 'Ópera de Sídney',
      city: 'Sídney',
      country: 'Australia',
      code: 'AU',
      lat: -33.8568,
      lng: 151.2153,
      wiki: 'Sydney_Opera_House',
      desc:
          'Sala de conciertos de techos curvos, terminada en 1973, ícono de Australia.',
      look:
          'Velas blancas de cerámica frente al puerto de Sídney, especial al atardecer.',
      food: 'Ostras frescas del puerto de Sídney.'),
  Site(
      name: 'Gran Barrera de Coral',
      city: 'Queensland',
      country: 'Australia',
      code: 'AU',
      lat: -18.2871,
      lng: 147.6992,
      wiki: 'Great_Barrier_Reef',
      desc:
          'El sistema de arrecifes de coral más grande del mundo, visible incluso desde el espacio.',
      look:
          'Aguas turquesas con miles de especies de peces y coral de colores.',
      food: 'Barramundi a la parrilla, pescado típico australiano.'),
  Site(
      name: 'Uluru',
      city: 'Territorio del Norte',
      country: 'Australia',
      code: 'AU',
      lat: -25.3444,
      lng: 131.0369,
      wiki: 'Uluru',
      desc:
          'Monolito sagrado para el pueblo aborigen anangu, en el centro de Australia.',
      look: 'Roca roja gigante que cambia de tono con la luz del atardecer.',
      food: 'Carne de canguro a la parrilla.'),
  Site(
      name: 'Milford Sound',
      city: 'Fiordland',
      country: 'Nueva Zelanda',
      code: 'NZ',
      lat: -44.6710,
      lng: 167.9250,
      wiki: 'Milford_Sound',
      desc:
          'Fiordo neozelandés considerado una de las maravillas naturales del mundo.',
      look:
          'Acantilados verticales cubiertos de bosque, cascadas y agua en calma casi todo el año.',
      food: 'Mejillones verdes neozelandeses al vapor.'),
  Site(
      name: 'Bora Bora',
      city: 'Islas de Sotavento',
      country: 'Polinesia Francesa',
      code: 'PF',
      lat: -16.5004,
      lng: -151.7415,
      wiki: 'Bora_Bora',
      desc:
          'Isla de la Polinesia Francesa famosa por su laguna turquesa y bungalós sobre el agua.',
      look:
          'Un anillo de coral rodeando un volcán extinto, con aguas de varios tonos de azul.',
      food: 'Poisson cru, pescado crudo marinado en leche de coco.'),
  Site(
      name: 'Hobbiton',
      city: 'Matamata',
      country: 'Nueva Zelanda',
      code: 'NZ',
      lat: -37.8722,
      lng: 175.6816,
      wiki: 'Hobbiton_Movie_Set',
      desc:
          "Set de filmación de 'El Señor de los Anillos' y 'El Hobbit', convertido en atracción turística.",
      look:
          'Casitas circulares excavadas en colinas verdes, como salidas directamente de la Comarca.',
      food: 'Cerveza artesanal en el pub Green Dragon del set.'),
];

// ---------------------------------------------------------------------------
// APP
// ---------------------------------------------------------------------------
class AtlasApp extends StatelessWidget {
  const AtlasApp({super.key});

  @override
  Widget build(BuildContext context) {
    const ink = Color(0xFF1E2A38);
    const parchment = Color(0xFFF4EFE1);
    const rust = Color(0xFFB5451B);
    const forest = Color(0xFF4C6B54);

    return MaterialApp(
      title: 'Atlas — Cuaderno de viaje',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        scaffoldBackgroundColor: parchment,
        primaryColor: ink,
        colorScheme: ColorScheme.fromSeed(
          seedColor: rust,
          primary: rust,
          secondary: forest,
          surface: parchment,
        ),
        fontFamily: 'Georgia',
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}

// ---------------------------------------------------------------------------
// PANTALLA PRINCIPAL
// ---------------------------------------------------------------------------
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String query = '';

  @override
  Widget build(BuildContext context) {
    final filtered = sites.where((s) {
      final q = query.toLowerCase();
      return s.name.toLowerCase().contains(q) ||
          s.city.toLowerCase().contains(q) ||
          s.country.toLowerCase().contains(q);
    }).toList();

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('CUADERNO DE VIAJE',
                      style: TextStyle(
                          fontFamily: 'Courier',
                          fontSize: 12,
                          letterSpacing: 2,
                          color: Color(0xFFB5451B),
                          fontWeight: FontWeight.w600)),
                  const SizedBox(height: 6),
                  const Text(
                    '64 sitios que vale la\npena cruzar el mapa',
                    style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF1E2A38),
                        height: 1.1),
                  ),
                  const SizedBox(height: 14),
                  TextField(
                    decoration: InputDecoration(
                      hintText: 'Buscar por lugar, ciudad o país...',
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(4),
                        borderSide: const BorderSide(color: Color(0xFF1E2A38)),
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 12),
                    ),
                    onChanged: (v) => setState(() => query = v),
                  ),
                  const SizedBox(height: 8),
                  Text('${filtered.length} lugares',
                      style: const TextStyle(
                          fontFamily: 'Courier',
                          fontSize: 12,
                          color: Color(0xFF4C6B54))),
                ],
              ),
            ),
            Expanded(
              child: filtered.isEmpty
                  ? const Center(
                      child: Text('Ningún lugar coincide con esa búsqueda.'))
                  : GridView.builder(
                      padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        mainAxisSpacing: 14,
                        crossAxisSpacing: 14,
                        childAspectRatio: 0.72,
                      ),
                      itemCount: filtered.length,
                      itemBuilder: (context, i) => SiteCard(site: filtered[i]),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// TARJETA DE SITIO (con imagen cargada desde Wikipedia)
// ---------------------------------------------------------------------------
class SiteCard extends StatelessWidget {
  final Site site;
  const SiteCard({super.key, required this.site});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => DetailScreen(site: site)),
      ),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(color: const Color(0x221E2A38)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              flex: 3,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  SiteImage(site: site),
                  Positioned(
                    top: 8,
                    right: 8,
                    child: Transform.rotate(
                      angle: -0.16,
                      child: Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: const Color(0xE6F4EFE1),
                          border: Border.all(
                              color: const Color(0xFFB5451B), width: 1.4),
                        ),
                        alignment: Alignment.center,
                        child: Text(site.code,
                            style: const TextStyle(
                                fontFamily: 'Courier',
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                                color: Color(0xFFB5451B))),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              flex: 2,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('${site.city.toUpperCase()} · ${site.country}',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontFamily: 'Courier',
                            fontSize: 9.5,
                            letterSpacing: 0.5,
                            color: Color(0xFF4C6B54))),
                    const SizedBox(height: 3),
                    Text(site.name,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF1E2A38))),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// IMAGEN DEL SITIO (obtenida en vivo desde la API de Wikipedia)
// ---------------------------------------------------------------------------
class SiteImage extends StatefulWidget {
  final Site site;
  const SiteImage({super.key, required this.site});
  @override
  State<SiteImage> createState() => _SiteImageState();
}

class _SiteImageState extends State<SiteImage> {
  static final Map<String, String?> _cache = {};
  String? _url;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (_cache.containsKey(widget.site.wiki)) {
      setState(() {
        _url = _cache[widget.site.wiki];
        _loading = false;
      });
      return;
    }
    try {
      final res = await http.get(Uri.parse(
          'https://es.wikipedia.org/api/rest_v1/page/summary/${widget.site.wiki}?redirect=true'));
      if (res.statusCode == 200) {
        final data = json.decode(utf8.decode(res.bodyBytes));
        final src =
            data['originalimage']?['source'] ?? data['thumbnail']?['source'];
        _cache[widget.site.wiki] = src;
        if (mounted)
          setState(() {
            _url = src;
            _loading = false;
          });
      } else {
        _cache[widget.site.wiki] = null;
        if (mounted) setState(() => _loading = false);
      }
    } catch (_) {
      _cache[widget.site.wiki] = null;
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_url != null) {
      return Image.network(
        _url!,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => _placeholder(),
        loadingBuilder: (context, child, progress) =>
            progress == null ? child : _placeholder(),
      );
    }
    return _placeholder();
  }

  Widget _placeholder() {
    return Container(
      color: const Color(0xFFECE4CF),
      alignment: Alignment.center,
      child: _loading
          ? const SizedBox(
              width: 18,
              height: 18,
              child: CircularProgressIndicator(strokeWidth: 2))
          : Text(widget.site.code,
              style: const TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.bold,
                  color: Color(0x441E2A38))),
    );
  }
}

// ---------------------------------------------------------------------------
// PANTALLA DE DETALLE
// ---------------------------------------------------------------------------
class DetailScreen extends StatefulWidget {
  final Site site;
  const DetailScreen({super.key, required this.site});
  @override
  State<DetailScreen> createState() => _DetailScreenState();
}

class _DetailScreenState extends State<DetailScreen> {
  String status =
      'Toca el botón para usar tu ubicación actual como punto de partida.';
  bool loading = false;

  Future<Position?> _determinePosition() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) return null;

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) return null;
    }
    if (permission == LocationPermission.deniedForever) return null;

    return await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
  }

  Future<void> _openWaze() async {
    setState(() {
      loading = true;
      status = 'Detectando tu ubicación...';
    });
    final site = widget.site;
    Position? pos;
    try {
      pos = await _determinePosition();
    } catch (_) {
      pos = null;
    }

    String url;
    if (pos != null) {
      setState(() => status =
          'Origen detectado: {pos!.latitude.toStringAsFixed(4)}, {pos.longitude.toStringAsFixed(4)} → abriendo Waze...');
      url =
          'https://waze.com/ul?ll={site.lat}%2C{site.lng}&navigate=yes&from={pos.latitude}%2C${pos.longitude}';
    } else {
      setState(() => status =
          'No se pudo obtener tu ubicación. Waze la pedirá al abrirse.');
      url = 'https://waze.com/ul?ll={site.lat}%2C{site.lng}&navigate=yes';
    }

    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      setState(() => status = 'No se pudo abrir Waze en este dispositivo.');
    }
    setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    final site = widget.site;
    return Scaffold(
      backgroundColor: const Color(0xFFF4EFE1),
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 240,
            pinned: true,
            backgroundColor: const Color(0xFF1E2A38),
            iconTheme: const IconThemeData(color: Colors.white),
            flexibleSpace: FlexibleSpaceBar(
              background: SiteImage(site: site),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(22, 22, 22, 40),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('${site.city.toUpperCase()} · ${site.country}',
                      style: const TextStyle(
                          fontFamily: 'Courier',
                          fontSize: 12,
                          letterSpacing: 1,
                          color: Color(0xFF4C6B54))),
                  const SizedBox(height: 6),
                  Text(site.name,
                      style: const TextStyle(
                          fontSize: 30,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF1E2A38))),
                  const SizedBox(height: 22),
                  _sectionLabel('QUÉ ES'),
                  Text(site.desc, style: _bodyStyle),
                  const SizedBox(height: 18),
                  _sectionLabel('CÓMO ES EL LUGAR'),
                  Text(site.look, style: _bodyStyle),
                  const SizedBox(height: 18),
                  _sectionLabel('COMIDA TÍPICA CERCA'),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    color: const Color(0xFF4C6B54),
                    child: Text(site.food,
                        style: const TextStyle(
                            fontFamily: 'Courier',
                            fontSize: 13,
                            color: Colors.white)),
                  ),
                  const SizedBox(height: 28),
                  Container(
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(color: const Color(0xFF1E2A38)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Cómo llegar',
                            style: TextStyle(
                                fontSize: 17, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 6),
                        Text(status,
                            style: const TextStyle(
                                fontFamily: 'Courier',
                                fontSize: 12,
                                color: Color(0xFF4C6B54))),
                        const SizedBox(height: 14),
                        ElevatedButton(
                          onPressed: loading ? null : _openWaze,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFB5451B),
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(2)),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 20, vertical: 12),
                          ),
                          child: Text(loading
                              ? 'Buscando ubicación...'
                              : '→ Ir con Waze'),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          'Waze abrirá la navegación en tiempo real desde donde te encuentres hasta ${site.name}.',
                          style: const TextStyle(
                              fontSize: 11.5, color: Colors.black54),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionLabel(String text) => Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: Text(text,
            style: const TextStyle(
                fontFamily: 'Courier',
                fontSize: 11,
                letterSpacing: 1,
                fontWeight: FontWeight.w600,
                color: Color(0xFFB5451B))),
      );

  static const _bodyStyle =
      TextStyle(fontSize: 14.5, height: 1.5, color: Color(0xFF1E2A38));
}
